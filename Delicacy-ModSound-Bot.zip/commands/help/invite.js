const discord = require("discord.js");

module.exports = {
  name: "invite",
  category: "info",
  description: "Invite the bot",
  run: async (client, message, args) => {
    
    let embed = new discord.MessageEmbed()
    .setTitle(`Invite our bot to your discord server`)
    .setDescription(`[📌 Click Here 📌](https://discord.com/api/oauth2/authorize?client_id=881293348172877924&permissions=8&scope=bot) or [📌 Join the server 📌](https://discord.gg/zj3UCPsd6Q)`)
    .setColor("RANDOM")
    .setFooter(`Powered by NateAles`)
    .setTimestamp(message.timestamp = Date.now())
    
    message.channel .send(embed)
    
  
  }
}