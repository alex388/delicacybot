const backup = require('discord-backup');
module.exports = {
    name: "backup-create",
    aliases: ["bc"],
    category: "backup",
    usage: "qbackup-create",
    description: "Get the bot's ping!",
    run: async (client, message, args) => {
      if(!message.member.hasPermission('MANAGE_MESSAGES')){
        return message.channel.send(':x: Для создания резервной копии на этом сервере у вас должны быть разрешения на управление сообщениями.');
    }

    backup.create(message.guild).then((backupData) => {

        return message.channel.send('Резервная копия создана! Вот ваш ID: `'+backupData.id+'` Используй `qload-backup '+backupData.id+'` для того чтобы загрузить резервную копию на другой сервер!');

    }).catch(() => {

        return message.channel.send(':x: Произошла ошибка, сообщите об этом на сервер поддержки. ');

    });

}
}