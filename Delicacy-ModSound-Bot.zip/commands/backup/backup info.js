const Discord = require('discord.js');
const backup = require('discord-backup');


module.exports = {
    name: 'info-backup',
    aliases: [],
    category: 'backup',
    

   run: async (client, message, args) => {
    // If the member doesn't have enough permissions
    if(!message.member.hasPermission('ADMINISTRATOR')){
        return message.reply(':x: У вас должны быть права администратора для создания резервной копии на этом сервере.');
    }

    const backupID = args.join(' ');

    if (!backupID)
        return message.channel.send(':x: Укажите действующий идентификатор резервной копии!');

    backup.fetch(backupID).then((backup) => {

        const date = new Date(backup.data.createdTimestamp);
        const yyyy = date.getFullYear().toString(), mm = (date.getMonth()+1).toString(), dd = date.getDate().toString();
        const formattedDate = `${yyyy}/${(mm[1]?mm:"0"+mm[0])}/${(dd[1]?dd:"0"+dd[0])}`;

        const embed = new Discord.MessageEmbed()
            .setAuthor(':information_source: Резервное копирование', backup.data.iconURL)
            .addField('Название сервера', backup.data.name)
            .addField('Размер', backup.size + ' kb')
            .addField('Создан в', formattedDate)
            .setFooter('ID резервной копии: '+backup.id);

        return message.channel.send(embed);

    }).catch((err) => {

        if (err === 'Резервная копия не найдена')
            return message.channel.send(':x: Резервная копия для идентификатора не найдена: '+backupID+'!');
        else
            return message.channel.send(':x: Произошла ошибка: '+(typeof err === 'string') ? err : JSON.stringify(err));

    });

  }
}
