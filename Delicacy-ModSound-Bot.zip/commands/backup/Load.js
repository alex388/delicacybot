const backup = require('discord-backup');
module.exports = {
    name: "backup-load",
    aliases: ["bload"],
    category: "backup",
    usage: "qbackup-load",
    description: "load a server backup",
    run: async (client, message, args) => {
      if(!message.member.hasPermission('ADMINISTRATOR')){
        return message.channel.send(':x: Для создания резервной копии на этом сервере у вас должны быть разрешения на управление сообщениями.');
    }

    const backupID = args.join(' ');

    backup.fetch(backupID).then(() => {

        message.channel.send(':warning: Все серверные каналы, роли и настройки будут очищены. Вы хотите продолжить? Напишите`-confirm` или `cancel`!');

        const collector = message.channel.createMessageCollector((m) => m.author.id === message.author.id && ['-confirm', 'cancel'].includes(m.content), {
            time: 60000,
            max: 1
        });
        collector.on('collect', (m) => {
            const confirm = m.content === '-confirm';
            collector.stop();
            if (confirm) {

                backup.load(backupID, message.guild).then(() => {

                    return message.author.send('Резервная копия успешно загружена!');
            
                }).catch((err) => {
            
                    if (err === 'No backup found')
                        return message.channel.send(':x: Резервная копия для идентификатора не найдена '+backupID+'!');
                    else
                        return message.author.send(':x: Произошла ошибка: '+(typeof err === 'string') ? err : JSON.stringify(err));
            
                });

            } else {
                return message.channel.send(':x: Отмененно.');
            }
        })

        collector.on('end', (collected, reason) => {
            if (reason === 'time')
                return message.channel.send(':x: Истекло время ожидания команды! Пожалуйста, попробуйте еще раз.');
        })

    }).catch(() => {
        return message.channel.send(':x: Резервная копия для идентификатора не найдена '+backupID+'!');
    });

}
}